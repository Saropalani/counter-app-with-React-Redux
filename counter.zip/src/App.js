import React from 'react'
import Input from './components/input'; 
import Output from './components/output'; 
import { Provider } from 'react-redux';
import store from './redux-file/store';

function App() {
  return (
    <Provider store={store}>
      <div className="App">
        <Input />
        <Output />
      </div>
    </Provider>
  );
}

export default App;
