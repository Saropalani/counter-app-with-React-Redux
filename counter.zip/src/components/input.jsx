import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import * as actions from '../redux-file/actions';
import Output from './output';

function Input() {
  const count = useSelector((state) => state.count);
  const dispatch = useDispatch();
  const [amountToAdd, setAmountToAdd] = useState(0); 

  const handleAddAmount = () => {
    dispatch(actions.incrementByAmount(parseInt(amountToAdd))); 
  };

  const handleAddAsync = () => {
    dispatch(actions.incrementAsync(parseInt(amountToAdd))); 
  };

  const handleAddIfOdd = () => {
    if (count % 2 !== 0) { 
      dispatch(actions.incrementByAmount(parseInt(amountToAdd))); 
    }
  };

  return (
    <div>
      <h1>Counter</h1>
      <div className='counter-button'>
      <button className='inc' onClick={() => dispatch(actions.increment())}>+</button>
      <span className='count-value'>{count}</span>
      <button className='dec' onClick={() => dispatch(actions.decrement())}>-</button>
      </div>
      <div className='input-container'>
        <input type="number"value={amountToAdd} className='input' onChange={(e) => setAmountToAdd(e.target.value)}/>
        <button className='add-amount' onClick={handleAddAmount}>ADD AMOUNT</button>
        <button className='add-async' onClick={handleAddAsync}>ADD ASYNC</button>
        <button className='add-odd' onClick={handleAddIfOdd}>ADD IF ODD</button>
      
      </div>
    </div>
  );
}

export default Input;
