import React from 'react';
import { useSelector } from 'react-redux';

const Output = () => {
  const count = useSelector(state => state.count);

  return (
    <div className='count'>
      <h2>OUTPUT :</h2>
      <p className='count-value'>{count}</p>
    </div>
  );
};

export default Output;
