import * as actionTypes from "./actiontypes";

const initialState = {
  count: 0,
  status: 'idle'
};

const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.INCREMENT:
      return {
        ...state,
        count: state.count + 1
      };

    case actionTypes.DECREMENT: 
      return {
        ...state,
        count: state.count - 1
      };

    case actionTypes.INCREMENT_BY_AMOUNT: 
      return {
        ...state,
        count: state.count + action.payload
      };

    case actionTypes.INCREMENT_ASYNC:
        return {
          ...state,
          status: 'loading',
          count: state.count + action.payload 
        };
    case actionTypes.INCREMENT_IF_ODD: 
      return {
        ...state,
        count: state.count % 2 !== 0 ? state.count + 1 : state.count
      };

    default:
      return state;
  }
};

export default rootReducer;
