import * as actionTypes from "./actiontypes";

export const increment = () => ({
  type: actionTypes.INCREMENT
});

export const decrement = () => ({
  type: actionTypes.DECREMENT
});

export const incrementByAmount = (amount) => ({
  type: actionTypes.INCREMENT_BY_AMOUNT,
  payload: amount
});

export const incrementAsync = (amount) => { 
  return (dispatch) => { setTimeout(() => {
      dispatch(incrementByAmount(amount)); 
    }, 500);
  };
};

export const addIfOdd = () => (dispatch, getState) => {
  const { count } = getState();
  if (count % 2 !== 0) {
    dispatch(increment());
  }
};
