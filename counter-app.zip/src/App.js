import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement } from './action';
import './App.css';
import './index.css'

function App() {
  const count = useSelector((state) => state.count);
  const dispatch = useDispatch();

  return (
    <div className="App">
      <h1>Counter</h1>
      <p className='count'>{count}</p>
      <button className='inc' onClick={() => dispatch(increment())}>+</button>
      <button className='dec' onClick={() => dispatch(decrement())}>-</button>
    </div>
  );
}

export default App;
